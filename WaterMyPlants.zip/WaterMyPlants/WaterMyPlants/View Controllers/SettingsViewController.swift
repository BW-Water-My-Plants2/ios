//
//  SettingsViewController.swift
//  WaterMyPlants
//
//  Created by Craig Belinfante on 10/18/20.
//  Copyright © 2020 Craig Belinfante. All rights reserved.
//

import UIKit

class SettingsViewController: UIViewController {

    // MARK: - IBActions -

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    }

}
