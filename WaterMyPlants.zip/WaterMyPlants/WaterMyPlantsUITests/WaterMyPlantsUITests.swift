//
//  WaterMyPlantsUITests.swift
//  WaterMyPlantsUITests
//
//  Created by Craig Belinfante on 10/13/20.
//  Copyright © 2020 Craig Belinfante. All rights reserved.
//

import XCTest

class WaterMyPlantsUITests: XCTestCase {

    override func setUpWithError() throws {
        continueAfterFailure = false
    }

    func testExample() throws {
        
    }

}
//let app = XCUIApplication()
//app.launch()
//app.textFields["Email"].tap()
//app.textFields["Username"].tap()
//app.secureTextFields["Password"].tap()
//app.buttons["eye"].tap()
//app.buttons["eye.slash"].tap()
//
//let app2 = app
//app2/*@START_MENU_TOKEN@*/.staticTexts["Sign Up"]/*[[".buttons.matching(identifier: \"Sign Up\").staticTexts[\"Sign Up\"]",".staticTexts[\"Sign Up\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
//app.alerts["Sign Up Successful"].scrollViews.otherElements.buttons["Ok"].tap()
//app2/*@START_MENU_TOKEN@*/.staticTexts["Sign In"]/*[[".buttons.matching(identifier: \"Sign In\").staticTexts[\"Sign In\"]",".staticTexts[\"Sign In\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
//app.navigationBars["Hello"].buttons["Add"].tap()
//app.navigationBars["WaterMyPlants.AddPlantsView"].buttons["Hello"].tap()
//app.collectionViews.cells.otherElements.containing(.image, identifier:"Plant1").element.tap()
//
//let watermyplantsPlantsdetailviewNavigationBar = app.navigationBars["WaterMyPlants.PlantsDetailView"]
//watermyplantsPlantsdetailviewNavigationBar.buttons["Edit"].tap()
//watermyplantsPlantsdetailviewNavigationBar.buttons["Done"].tap()
//app2/*@START_MENU_TOKEN@*/.staticTexts["Add Photo of your plant"]/*[[".buttons[\"Add Photo of your plant\"].staticTexts[\"Add Photo of your plant\"]",".staticTexts[\"Add Photo of your plant\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
